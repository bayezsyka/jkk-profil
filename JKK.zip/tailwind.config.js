/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
        './resources/js/**/*.tsx',
        './resources/js/**/*.ts',
    ],
    theme: {
        extend: {
            colors: {
                // JKK Brand Colors - Based on Logo
                'jkk': {
                    'blue-light': '#6B8BB8',    // Biru terang (bar kiri logo)
                    'blue': '#5A7BA5',          // Biru sedang (bar tengah logo)
                    'blue-dark': '#4A6A95',     // Biru gelap (bar kanan logo)
                    'navy': '#3D5A85',          // Navy untuk footer/dark sections
                    'charcoal': '#2D2E2F',      // Abu gelap dari swoosh
                    'white': '#FFFFFF',         // Putih bersih
                    'off-white': '#F8FAFB',     // Off-white untuk background
                },
                // Shorthand aliases
                'primary': '#5A7BA5',       // Biru utama (dari logo)
                'secondary': '#3D5A85',     // Navy untuk accent
                'accent': '#6B8BB8',        // Biru terang untuk highlight
                'dark': '#2D2E2F',          // Charcoal dari swoosh
                'light': '#F8FAFB',         // Background terang
            },
            fontFamily: {
                'sans': ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
            },
        },
    },
    plugins: [require('@tailwindcss/forms')],
};
