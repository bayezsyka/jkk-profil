<?php

return [
    'phone' => env('COMPANY_PHONE', '(0283) 673063'),
    'whatsapp' => env('COMPANY_WHATSAPP', '+6285786992000'),
    'email_1' => env('COMPANY_EMAIL_1', 'jayakarya093@gmail.com'),
    'email_2' => env('COMPANY_EMAIL_2', 'jayakarya24@gmail.com'),
    'address' => env('COMPANY_ADDRESS', 'Jl. Raya Jatiwaringin No. 123, Pondok Gede, Bekasi 17411'),
];
