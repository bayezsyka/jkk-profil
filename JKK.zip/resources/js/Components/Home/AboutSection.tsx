import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

const AboutSection: React.FC = () => {
    const { t } = useLanguage();

    const cards = [
        {
            icon: (
                <svg className="w-8 h-8" fill="white" viewBox="0 0 24 24">
                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-7-2h2v-4h4v-2h-4V7h-2v4H8v2h4z"/>
                </svg>
            ),
            title: t('about.construction.title'),
            description: t('about.construction.desc'),
        },
        {
            icon: (
                <svg className="w-8 h-8" fill="white" viewBox="0 0 24 24">
                    <path d="M6.5 10h-2v7h2v-7zm6 0h-2v7h2v-7zm8.5 9H2v2h19v-2zm-2.5-9h-2v7h2v-7zm-7-6.74L16.71 6H6.29l5.21-2.74m0-2.26L2 6v2h19V6l-9.5-5z"/>
                </svg>
            ),
            title: t('about.infrastructure.title'),
            description: t('about.infrastructure.desc'),
        },
        {
            icon: (
                <svg className="w-8 h-8" fill="white" viewBox="0 0 24 24">
                    <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/>
                </svg>
            ),
            title: t('about.energy.title'),
            description: t('about.energy.desc'),
        },
    ];

    return (
        <section
            id="about"
            style={{
                padding: '100px 24px',
                background: 'linear-gradient(180deg, #F8FAFB 0%, #EEF2F6 100%)',
            }}
        >
            <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                <h2
                    style={{
                        textAlign: 'center',
                        fontSize: 'clamp(2rem, 5vw, 3rem)',
                        fontWeight: 700,
                        color: '#2D2E2F',
                        marginBottom: '64px',
                        letterSpacing: '-0.02em',
                    }}
                >
                    {t('about.title')}
                </h2>

                <div
                    className="about-cards-grid"
                    style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                        gap: '32px',
                    }}
                >
                    {cards.map((card, index) => (
                        <div
                            key={index}
                            className="about-card"
                            style={{
                                backgroundColor: 'white',
                                borderRadius: '24px',
                                padding: '40px 32px',
                                boxShadow: '0 4px 24px rgba(0, 0, 0, 0.06)',
                                border: '1px solid rgba(0, 0, 0, 0.05)',
                                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                                cursor: 'pointer',
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.transform = 'translateY(-8px)';
                                e.currentTarget.style.boxShadow = '0 12px 40px rgba(90, 123, 165, 0.15)';
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.transform = 'translateY(0)';
                                e.currentTarget.style.boxShadow = '0 4px 24px rgba(0, 0, 0, 0.06)';
                            }}
                        >
                            <div
                                style={{
                                    width: '72px',
                                    height: '72px',
                                    borderRadius: '16px',
                                    background: 'linear-gradient(135deg, #5A7BA5 0%, #3D5A85 100%)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    marginBottom: '24px',
                                }}
                            >
                                {card.icon}
                            </div>

                            <h3
                                style={{
                                    fontSize: '20px',
                                    fontWeight: 700,
                                    color: '#2D2E2F',
                                    marginBottom: '12px',
                                }}
                            >
                                {card.title}
                            </h3>

                            <p
                                style={{
                                    fontSize: '15px',
                                    color: '#6b7280',
                                    lineHeight: 1.7,
                                }}
                            >
                                {card.description}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default AboutSection;
