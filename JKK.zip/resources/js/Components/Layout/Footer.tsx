import React from 'react';
import { usePage } from '@inertiajs/react';
import { PageProps } from '@/types';

const Footer: React.FC = () => {
    const { company } = usePage<PageProps>().props;
    const currentYear = new Date().getFullYear();

    return (
        <footer>
            {/* Main Footer - Using logo blue */}
            <div 
                style={{
                    backgroundColor: '#5A7BA5',
                    color: '#FFFFFF',
                    padding: '24px 32px 20px',
                }}
            >
                <div
                    style={{
                        maxWidth: '1200px',
                        margin: '0 auto',
                    }}
                >
                    {/* Top Row - Company Name & Sitemap */}
                    <div
                        style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            marginBottom: '16px',
                        }}
                    >
                        <h3
                            style={{
                                fontSize: '16px',
                                fontWeight: 700,
                                color: '#FFFFFF',
                                margin: 0,
                            }}
                        >
                            PT. JAYA KARYA KONTRUKSI
                        </h3>
                    </div>

                    {/* Bottom Row - Address & Contact */}
                    <div
                        style={{
                            display: 'flex',
                            flexWrap: 'wrap',
                            justifyContent: 'space-between',
                            alignItems: 'flex-start',
                            gap: '24px',
                        }}
                    >
                        {/* Address */}
                        <p
                            style={{
                                fontSize: '13px',
                                color: 'rgba(255, 255, 255, 0.85)',
                                margin: 0,
                                maxWidth: '450px',
                                lineHeight: 1.5,
                            }}
                        >
                            {company.address}
                        </p>

                        {/* Contact Info */}
                        <div
                            style={{
                                display: 'flex',
                                gap: '32px',
                                alignItems: 'center',
                            }}
                        >
                            <a
                                href={`tel:${company.phone.replace(/[()\s-]/g, '')}`}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    color: '#FFFFFF',
                                    textDecoration: 'none',
                                    fontSize: '13px',
                                }}
                            >
                                <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
                                </svg>
                                <span>{company.phone}</span>
                            </a>

                            <a
                                href={`mailto:${company.email_1}`}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    color: '#FFFFFF',
                                    textDecoration: 'none',
                                    fontSize: '13px',
                                }}
                            >
                                <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" />
                                </svg>
                                <span>{company.email_1}</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Bar - Using darker navy from logo */}
            <div
                style={{
                    backgroundColor: '#3D5A85',
                    color: '#FFFFFF',
                    padding: '14px 32px',
                }}
            >
                <div
                    style={{
                        maxWidth: '1200px',
                        margin: '0 auto',
                        display: 'flex',
                        flexWrap: 'wrap',
                        justifyContent: 'center',
                        alignItems: 'center',
                        gap: '16px',
                    }}
                >
                    {/* Copyright */}
                    <p
                        style={{
                            fontSize: '12px',
                            color: 'rgba(255, 255, 255, 0.7)',
                            margin: 0,
                        }}
                    >
                        &copy; {currentYear} PT. JAYA KARYA KONTRUKSI. All rights reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
