export { default as HeroSection } from './HeroSection';
export { default as Services } from './Services';
export { default as LatestProjectsSection } from './LatestProjectsSection';
export { default as PhotoGallerySection } from './PhotoGallerySection';
export { default as LatestArticlesSection } from './LatestArticlesSection';
// export { default as AboutSection } from './AboutSection';
// export { default as ContactSection } from './ContactSection';
