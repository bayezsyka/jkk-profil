<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConcretePrice extends Model
{
    protected $guarded = [];
}
